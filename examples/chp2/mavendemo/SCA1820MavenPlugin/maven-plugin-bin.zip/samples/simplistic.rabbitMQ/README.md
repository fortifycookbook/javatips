jso.camp2014.simplistic.rabbitMQ.jca.poc
========================================

A very simplistic wildfly/rabbit/rar PoC - it just works (non-production code)
